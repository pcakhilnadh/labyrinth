<!-- Website design by geets -->

<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>GNOSIS Quiz '12</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" />
		<link href='http://fonts.googleapis.com/css?family=Medula+One' rel='stylesheet' type='text/css'>
		<!--[if IE 7]>
			<link rel="stylesheet" href="css/ie7.css" type="text/css" />
		<![endif]-->
	</head>
	<body>
		<div class="page">
			<div class="header">
				<a href="index.php" id="logo"><img src="images/logo.png" alt=""/></a>
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="rules.html">Rules</b></a></li>
					<li class="selected"><a href="login.php">Login</a></li>
					<li><a href="memberlist.php">Leaderboard</a></li>
				</ul>
			</div>
			<div class="body">
					<div id="hbc"> <img src="images/hbc.png"> </div>
					<div class="desc">
						<a><p> sdfsdg wrehgergoijnerg erhwet herhe therqwhrowehqinerh
							lksdgfwsihgwra;ngpoerhjgsxreoingfx sadfiwbeofi wefgi]bv ewroiugvbe eoriuvbhreav ouwqgfe
							lkjbf aerglikjreg rthrt hsrthet htehet heth werte rtruy jfg frgdsf
						eqrherqhijnerh erhewihjnewfhb etnheotwbhwtenb ewtnoetijnbetnb etnoietnet </p></a>
					</div>
						<div class="reg"> <a href="register.php"><img src="images/reg.png"  alt="Register"></a> </div>
						<div class="log1"> <a href="login.php"><img src="images/lod.png"  alt="Login"></a> </div>
				
				
			</div>
			<div class="footer">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="rules.html">Rules</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="memberlist.php">Leaderboard</a></li>
				</ul>
				<p>&#169; Copyright &#169; 2012. Design by <a href="http://facebook.com/geetsin">geets</a></p>
				<div class="connect">
					<a href="https://www.facebook.com/cecfoces" id="facebook">facebook</a>
				</div>
					<a href="http://www.summit12.in/" id="twitter"><img src="images/summit.png" alt="Summit 2012"></a>
					<a href="https://www.facebook.com/cecfoces" id="vimeo"><img src="images/foces.png" alt="CEC FOCES"></a>
					
				
			</div>
		</div>
	</body>
</html>  